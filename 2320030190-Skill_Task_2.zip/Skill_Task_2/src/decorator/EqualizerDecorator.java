package decorator;

public class EqualizerDecorator implements BaseMusicPlayer {
    private BaseMusicPlayer player;

    public EqualizerDecorator(BaseMusicPlayer player) {
        this.player = player;
    }

    @Override
    public void play() {
        player.play();
        System.out.println("Applying equalizer settings...");
    }
}
