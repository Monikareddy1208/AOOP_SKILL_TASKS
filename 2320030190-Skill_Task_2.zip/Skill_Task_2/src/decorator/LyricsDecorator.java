package decorator;

public class LyricsDecorator implements BaseMusicPlayer {
    private BaseMusicPlayer player;

    public LyricsDecorator(BaseMusicPlayer player) {
        this.player = player;
    }

    @Override
    public void play() {
        player.play();
        System.out.println("Displaying lyrics...");
    }
}
