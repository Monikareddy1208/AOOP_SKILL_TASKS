package decorator;

public interface BaseMusicPlayer {
    void play();
}
