package main;

import player.*;
import sources.*;
import decorator.*;

public class Main {
    public static void main(String[] args) {
        // Using Adapter Pattern for Different Sources
        MusicSource local = new LocalMusic();
        MusicSource online = new OnlineStreaming();
        MusicSource radio = new RadioStation();

        // Using Bridge Pattern for Music Player
        MusicPlayer localPlayer = new BasicMusicPlayer(local);
        MusicPlayer onlinePlayer = new BasicMusicPlayer(online);
        MusicPlayer radioPlayer = new BasicMusicPlayer(radio);

        System.out.println("=== Playing Different Music Sources ===");
        localPlayer.play();
        onlinePlayer.play();
        radioPlayer.play();

        // Using Decorator Pattern to Enhance Player
        System.out.println("\n=== Enhanced Music Player with Equalizer and Lyrics ===");
        BaseMusicPlayer decoratedPlayer = new EqualizerDecorator(new LyricsDecorator(() -> {
            System.out.println("Playing music...");
        }));
        decoratedPlayer.play();
    }
}
