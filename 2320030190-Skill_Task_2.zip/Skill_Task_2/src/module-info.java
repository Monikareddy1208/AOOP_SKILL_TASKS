/**
 * 
 */
/**
 * 
 */
module Skill_Task_2 {
}