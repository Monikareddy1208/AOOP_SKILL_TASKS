package sources;

public class RadioStation implements MusicSource {
    @Override
    public void playMusic() {
        System.out.println("Playing music from a radio station...");
    }
}
