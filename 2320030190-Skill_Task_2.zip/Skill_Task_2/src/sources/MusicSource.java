package sources;

public interface MusicSource {
    void playMusic();
}
