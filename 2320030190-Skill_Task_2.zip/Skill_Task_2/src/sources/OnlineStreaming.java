package sources;

public class OnlineStreaming implements MusicSource {
    @Override
    public void playMusic() {
        System.out.println("Streaming music from online services...");
    }
}
