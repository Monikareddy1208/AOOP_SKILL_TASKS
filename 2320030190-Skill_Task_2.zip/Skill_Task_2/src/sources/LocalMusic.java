package sources;

public class LocalMusic implements MusicSource {
    @Override
    public void playMusic() {
        System.out.println("Playing music from local files...");
    }
}
