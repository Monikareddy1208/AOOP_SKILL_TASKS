package player;

import sources.MusicSource;

public class BasicMusicPlayer extends MusicPlayer {

    public BasicMusicPlayer(MusicSource musicSource) {
        super(musicSource);
    }

    @Override
    public void play() {
        System.out.println("Using Basic Music Player...");
        musicSource.playMusic();
    }
}
