package game;

public interface Level {
    void play();
}

class EasyLevel implements Level {
    public void play() {
        System.out.println("Playing Easy Level...");
    }
}

class HardLevel implements Level {
    public void play() {
        System.out.println("Playing Hard Level...");
    }
}