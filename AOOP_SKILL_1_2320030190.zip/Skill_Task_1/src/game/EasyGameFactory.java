package game;

public class EasyGameFactory extends AbstractGameFactory {
    public Game createGame() {
        return new EasyGame();
    }
}