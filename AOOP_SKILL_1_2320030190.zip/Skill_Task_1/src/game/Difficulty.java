package game;

public class Difficulty {

}
