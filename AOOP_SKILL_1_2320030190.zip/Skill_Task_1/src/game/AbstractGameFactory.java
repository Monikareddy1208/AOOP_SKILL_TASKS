package game;

public abstract class AbstractGameFactory {
    public abstract Game createGame();
}