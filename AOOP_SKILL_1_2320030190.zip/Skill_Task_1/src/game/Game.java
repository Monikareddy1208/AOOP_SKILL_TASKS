package game;

public interface Game {
    void start();
}

class EasyGame implements Game {
    public void start() {
        System.out.println("Starting an Easy Game...");
    }
}

class HardGame implements Game {
    public void start() {
        System.out.println("Starting a Hard Game...");
    }
}