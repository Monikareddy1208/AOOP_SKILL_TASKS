package game;

public class SingletonGameManager {
    private static SingletonGameManager instance;

    private SingletonGameManager() {}

    public static SingletonGameManager getInstance() {
        if (instance == null) {
            instance = new SingletonGameManager();
        }
        return instance;
    }

    public void startGame() {
        System.out.println("Game started...");
    }
}