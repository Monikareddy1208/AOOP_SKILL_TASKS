package game;

public class HardGameFactory extends AbstractGameFactory {
    public Game createGame() {
        return new HardGame();
    }
}