/**
 * 
 */
/**
 * 
 */
module Skill_Task_1 {
}