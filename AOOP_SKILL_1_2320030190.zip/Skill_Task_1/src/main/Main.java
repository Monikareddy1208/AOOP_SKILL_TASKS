// File: Main.java
package main;

import game.*;
import ride.*;

public class Main {
    public static void main(String[] args) {
        // Singleton Pattern for Game
        SingletonGameManager gameManager = SingletonGameManager.getInstance();
        gameManager.startGame();

        // Factory Method for Game Level
        Level easyLevel = GameFactory.getLevel("easy");
        easyLevel.play();
        Level hardLevel = GameFactory.getLevel("hard");
        hardLevel.play();

        // Abstract Factory for Game Creation
        AbstractGameFactory easyGameFactory = new EasyGameFactory();
        Game easyGame = easyGameFactory.createGame();
        easyGame.start();

        AbstractGameFactory hardGameFactory = new HardGameFactory();
        Game hardGame = hardGameFactory.createGame();
        hardGame.start();

        // Singleton Pattern for Ride Management (Ensure Proper Initialization)
        SingletonRideManager rideManager = SingletonRideManager.getInstance();
        if (rideManager != null) {
            rideManager.requestRide();
        } else {
            System.out.println("Error: Ride Manager instance is null!");
        }

        // Factory Method for Vehicle Selection
        Vehicle car = VehicleFactory.getVehicle("car");
        car.ride();
        Vehicle bike = VehicleFactory.getVehicle("bike");
        bike.ride();
        Vehicle scooter = VehicleFactory.getVehicle("scooter");
        scooter.ride();

        // Abstract Factory for Ride Selection
        AbstractRideFactory cityRideFactory = new CityRideFactory();
        Ride cityRide = cityRideFactory.createRide();
        cityRide.start();

        AbstractRideFactory offRoadRideFactory = new OffRoadRideFactory();
        Ride offRoadRide = offRoadRideFactory.createRide();
        offRoadRide.start();
    }
}
