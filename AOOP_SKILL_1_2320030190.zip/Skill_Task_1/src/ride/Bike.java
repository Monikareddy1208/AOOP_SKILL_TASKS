package ride;

public class Bike implements Vehicle {
    public void ride() {
        System.out.println("Riding a Bike...");
    }
}
