package ride;

public class CityRideFactory extends AbstractRideFactory {
    public Ride createRide() {
        return new CityRide();
    }
}