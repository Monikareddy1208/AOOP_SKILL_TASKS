package ride;

public class Scooter implements Vehicle {
    public void ride() {
        System.out.println("Riding a Scooter...");
    }
}