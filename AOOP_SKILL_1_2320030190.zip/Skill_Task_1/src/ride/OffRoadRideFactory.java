package ride;

public class OffRoadRideFactory extends AbstractRideFactory {
    public Ride createRide() {
        return new OffRoadRide();
    }
}