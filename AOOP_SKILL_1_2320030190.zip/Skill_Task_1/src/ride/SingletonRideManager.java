package ride;

public class SingletonRideManager {
    private static SingletonRideManager instance;

    private SingletonRideManager() {}

    public static SingletonRideManager getInstance() {
        if (instance == null) {
            instance = new SingletonRideManager();
        }
        return instance;
    }

    public void requestRide() {
        System.out.println("Ride requested...");
    }
}
