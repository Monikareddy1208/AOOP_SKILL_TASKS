package ride;

public interface Vehicle {
    void ride();
}