package ride;

public abstract class AbstractRideFactory {
    public abstract Ride createRide();
}
