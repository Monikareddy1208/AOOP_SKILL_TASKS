package ride;

public interface Ride {
    void start();
}

class CityRide implements Ride {
    public void start() {
        System.out.println("Starting a City Ride...");
    }
}

class OffRoadRide implements Ride {
    public void start() {
        System.out.println("Starting an Off-Road Ride...");
    }
}
