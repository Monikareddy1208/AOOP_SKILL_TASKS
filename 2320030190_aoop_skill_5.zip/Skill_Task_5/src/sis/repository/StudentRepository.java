package sis.repository;

import sis.model.Student;
import java.util.HashMap;
import java.util.Map;

// Repository Class to Store Students (Follows Single Responsibility)
public class StudentRepository {
    private Map<Integer, Student> students = new HashMap<>();

    public void addStudent(Student student) {
        students.put(student.getId(), student);
    }

    public Student getStudent(int id) {
        return students.get(id);
    }

    public boolean removeStudent(int id) {
        return students.remove(id) != null;
    }

    public Map<Integer, Student> getAllStudents() {
        return students;
    }
}
