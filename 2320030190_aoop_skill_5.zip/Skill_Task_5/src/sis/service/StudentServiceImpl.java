package sis.service;

import sis.model.Student;
import sis.repository.StudentRepository;
import sis.exception.StudentNotFoundException;
import java.util.Map;

// Implements Service Interface (Liskov Substitution)
public class StudentServiceImpl implements StudentService {
    private StudentRepository repository;

    public StudentServiceImpl(StudentRepository repository) {
        this.repository = repository;
    }

    @Override
    public void addStudent(Student student) {
        repository.addStudent(student);
    }

    @Override
    public Student getStudent(int id) {
        Student student = repository.getStudent(id);
        if (student == null) {
            throw new StudentNotFoundException("Student not found with ID: " + id);
        }
        return student;
    }

    @Override
    public boolean removeStudent(int id) {
        return repository.removeStudent(id);
    }

    @Override
    public Map<Integer, Student> getAllStudents() {
        return repository.getAllStudents();
    }
}
