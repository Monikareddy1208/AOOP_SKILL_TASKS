package sis.service;

import sis.model.Student;
import java.util.Map;

// Interface Segregation Principle (Only Necessary Methods)
public interface StudentService {
    void addStudent(Student student);
    Student getStudent(int id);
    boolean removeStudent(int id);
    Map<Integer, Student> getAllStudents();
}
