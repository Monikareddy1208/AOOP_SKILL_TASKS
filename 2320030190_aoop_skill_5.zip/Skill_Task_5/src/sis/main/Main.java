package sis.main;

import sis.model.*;
import sis.service.*;
import sis.repository.*;

public class Main {
    public static void main(String[] args) {
        StudentRepository repository = new StudentRepository();
        StudentService service = new StudentServiceImpl(repository);

        // Adding Students
        service.addStudent(new UndergraduateStudent(101, "Alice", 20));
        service.addStudent(new GraduateStudent(102, "Bob", 25));

        // Retrieve and Display Student
        Student student = service.getStudent(101);
        System.out.println("Student: " + student.getName() + ", Type: " + student.getStudentType());

        // Display All Students
        service.getAllStudents().forEach((id, stu) -> {
            System.out.println("ID: " + id + ", Name: " + stu.getName());
        });
    }
}
