package sis.model;

// Undergraduate Student (Extends Student)
public class UndergraduateStudent extends Student {
    public UndergraduateStudent(int id, String name, int age) {
        super(id, name, age);
    }

    @Override
    public String getStudentType() {
        return "Undergraduate";
    }
}
