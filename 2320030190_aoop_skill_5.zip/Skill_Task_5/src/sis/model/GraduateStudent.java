package sis.model;

// Graduate Student (Extends Student)
public class GraduateStudent extends Student {
    public GraduateStudent(int id, String name, int age) {
        super(id, name, age);
    }

    @Override
    public String getStudentType() {
        return "Graduate";
    }
}
