module Skill_Task_5 {
    requires junit;
    requires org.junit.jupiter.api;
    exports sis.service;
}
