package test.sis.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import sis.model.*;
import sis.repository.*;
import sis.exception.StudentNotFoundException;
import sis.service.StudentService;
import sis.service.StudentServiceImpl;


class StudentServiceTest {
    @Test
    void testAddAndRetrieveStudent() {
        StudentRepository repository = new StudentRepository();
        StudentService service = new StudentServiceImpl(repository);

        Student student = new UndergraduateStudent(101, "Alice", 20);
        service.addStudent(student);

        assertEquals("Alice", service.getStudent(101).getName());
    }

    @Test
    void testRemoveStudent() {
        StudentRepository repository = new StudentRepository();
        StudentService service = new StudentServiceImpl(repository);

        service.addStudent(new GraduateStudent(102, "Bob", 25));
        assertTrue(service.removeStudent(102));
        assertThrows(StudentNotFoundException.class, () -> service.getStudent(102));
    }
}
