/**
 * 
 */
/**
 * 
 */
module Skill_Task_8 {
}