package employeestream;

import java.util.*;
import java.util.stream.Collectors;

public class EmployeeService {

    // Generate a list of 10 sample employees
    public static List<Employee> getSampleEmployees() {
        return Arrays.asList(
            new Employee(1, "Alice", "HR", 45000),
            new Employee(2, "Bob", "IT", 70000),
            new Employee(3, "Charlie", "Finance", 60000),
            new Employee(4, "David", "IT", 85000),
            new Employee(5, "Emma", "HR", 48000),
            new Employee(6, "Frank", "Finance", 75000),
            new Employee(7, "Grace", "IT", 90000),
            new Employee(8, "Hank", "Finance", 65000),
            new Employee(9, "Ivy", "Marketing", 50000),
            new Employee(10, "Jack", "IT", 72000)
        );
    }

    // Filter employees with salary > 50000
    public static List<Employee> filterHighSalaryEmployees(List<Employee> employees) {
        return employees.stream()
                .filter(e -> e.getSalary() > 50000)
                .collect(Collectors.toList());
    }

    // Sort employees by salary (ascending order)
    public static List<Employee> sortEmployeesBySalary(List<Employee> employees) {
        return employees.stream()
                .sorted(Comparator.comparingDouble(Employee::getSalary))
                .collect(Collectors.toList());
    }

    // Find the employee with the highest salary
    public static Optional<Employee> findHighestSalary(List<Employee> employees) {
        return employees.stream()
                .max(Comparator.comparingDouble(Employee::getSalary));
    }

    // Calculate the average salary
    public static double calculateAverageSalary(List<Employee> employees) {
        return employees.stream()
                .mapToDouble(Employee::getSalary)
                .average()
                .orElse(0.0); // Default to 0 if the list is empty
    }
}
