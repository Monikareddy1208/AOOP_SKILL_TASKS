package employeestream;

import java.util.List;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        List<Employee> employees = EmployeeService.getSampleEmployees();

        System.out.println("\n📋 All Employees:");
        employees.forEach(System.out::println);

        // Filtering employees with salary > 50000
        System.out.println("\n💰 Employees with Salary > 50000:");
        EmployeeService.filterHighSalaryEmployees(employees).forEach(System.out::println);

        // Sorting employees by salary
        System.out.println("\n📊 Employees Sorted by Salary:");
        EmployeeService.sortEmployeesBySalary(employees).forEach(System.out::println);

        // Finding highest salary employee
        Optional<Employee> highestPaid = EmployeeService.findHighestSalary(employees);
        highestPaid.ifPresent(emp -> System.out.println("\n🏆 Employee with Highest Salary: " + emp));

        // Calculating average salary
        double averageSalary = EmployeeService.calculateAverageSalary(employees);
        System.out.println("\n📈 Average Salary: $" + averageSalary);
    }
}
