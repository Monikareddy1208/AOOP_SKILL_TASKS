/**
 * 
 */
/**
 * 
 */
module Skill_Task_6 {
}