package Main.employee;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Creating Employee List
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("Alice", 30, 60000, "HR"));
        employees.add(new Employee("Bob", 25, 50000, "IT"));
        employees.add(new Employee("Charlie", 35, 70000, "Finance"));
        employees.add(new Employee("David", 28, 45000, "Marketing"));
        employees.add(new Employee("Eve", 40, 80000, "IT"));

        // 🔹 Sorting by Salary (Default - Comparable)
        System.out.println("\n🔹 Sorting by Salary (Default - Comparable)");
        Collections.sort(employees);
        employees.forEach(System.out::println);

        // 🔹 Sorting by Name (Comparator)
        System.out.println("\n🔹 Sorting by Name");
        Collections.sort(employees, new EmployeeComparator.NameComparator());
        employees.forEach(System.out::println);

        // 🔹 Sorting by Age (Comparator)
        System.out.println("\n🔹 Sorting by Age");
        Collections.sort(employees, new EmployeeComparator.AgeComparator());
        employees.forEach(System.out::println);

        // 🔹 Sorting by Department (Comparator)
        System.out.println("\n🔹 Sorting by Department");
        Collections.sort(employees, new EmployeeComparator.DepartmentComparator());
        employees.forEach(System.out::println);

        // 🔹 Demonstrating Cloning
        System.out.println("\n🔹 Cloning an Employee");
        Employee original = employees.get(0);
        Employee cloned = original.clone();
        System.out.println("Original: " + original);
        System.out.println("Cloned: " + cloned);

        // 🔹 Demonstrating Iteration
        System.out.println("\n🔹 Iterating over Employees");
        Iterator<Employee> iterator = employees.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}
