package main;

import logger.Logger;
import logger.LoggerChain;

public class Main {
    public static void main(String[] args) {
        Logger loggerChain = LoggerChain.getLoggerChain();

        System.out.println("=== Logging Messages ===");
        loggerChain.logMessage(Logger.INFO, "Application started.");
        loggerChain.logMessage(Logger.DEBUG, "Debugging application flow.");
        loggerChain.logMessage(Logger.ERROR, "System crash detected!");
    }
}