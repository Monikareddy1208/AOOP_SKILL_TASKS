/**
 * 
 */
/**
 * 
 */
module Skill_Task_3 {
}