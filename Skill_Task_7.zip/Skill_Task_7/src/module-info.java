/**
 * 
 */
/**
 * 
 */
module Skill_Task_7 {
}