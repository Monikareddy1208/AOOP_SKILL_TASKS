package contactmanager;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ContactManager manager = new ContactManager();
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("\n📞 Contact Manager");
            System.out.println("1. Add Contact");
            System.out.println("2. View Contact");
            System.out.println("3. Remove Contact");
            System.out.println("4. Display All Contacts");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Phone: ");
                    String phone = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String email = scanner.nextLine();
                    manager.addContact(new Contact(name, phone, email));
                    break;
                
                case 2:
                    System.out.print("Enter Name: ");
                    String searchName = scanner.nextLine();
                    Contact found = manager.getContactByName(searchName);
                    if (found != null) {
                        System.out.println("✔ Found: " + found);
                    } else {
                        System.out.println("⚠ Contact not found!");
                    }
                    break;

                case 3:
                    System.out.print("Enter Name to remove: ");
                    String removeName = scanner.nextLine();
                    manager.removeContact(removeName);
                    break;

                case 4:
                    manager.displayContacts();
                    break;

                case 5:
                    System.out.println("📴 Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("⚠ Invalid choice. Try again.");
            }
        }
    }
}
