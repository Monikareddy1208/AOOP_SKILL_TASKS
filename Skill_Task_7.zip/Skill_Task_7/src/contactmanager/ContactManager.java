package contactmanager;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ContactManager {
    private Set<Contact> contactsSet; // Ensures unique contacts
    private Map<String, Contact> contactsMap; // Quick lookup by name

    public ContactManager() {
        this.contactsSet = new HashSet<>();
        this.contactsMap = new HashMap<>();
    }

    // Add a contact
    public void addContact(Contact contact) {
        if (contactsSet.add(contact)) {  // Ensures uniqueness
            contactsMap.put(contact.getName(), contact);
            System.out.println("✔ Contact added: " + contact);
        } else {
            System.out.println("⚠ Contact already exists: " + contact);
        }
    }

    // Get contact by name (O(1) lookup)
    public Contact getContactByName(String name) {
        return contactsMap.get(name);
    }

    // Remove a contact
    public void removeContact(String name) {
        Contact contact = contactsMap.remove(name);
        if (contact != null) {
            contactsSet.remove(contact);
            System.out.println("✔ Contact removed: " + contact);
        } else {
            System.out.println("⚠ Contact not found: " + name);
        }
    }

    // Display all contacts
    public void displayContacts() {
        if (contactsSet.isEmpty()) {
            System.out.println("No contacts available.");
        } else {
            System.out.println("\n📒 Contact List:");
            for (Contact contact : contactsSet) {
                System.out.println(contact);
            }
        }
    }
}
