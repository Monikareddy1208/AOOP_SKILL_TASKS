package auction;

public class Main {
    public static void main(String[] args) {
        // Create Auctioneer
        Auctioneer auctioneer = new Auctioneer("Antique Vase");

        // Create Bidders
        Bidder bidder1 = new Bidder("Alice");
        Bidder bidder2 = new Bidder("Bob");
        Bidder bidder3 = new Bidder("Charlie");

        // Register Bidders
        auctioneer.registerBidder(bidder1);
        auctioneer.registerBidder(bidder2);
        auctioneer.registerBidder(bidder3);

        // Start Auction
        StandardAuction auction = new StandardAuction("Antique Vase", 100.0, auctioneer);
        auction.startAuction();

        // Bidders Place Bids
        bidder1.placeBid(auctioneer, 150);
        bidder2.placeBid(auctioneer, 200);
        bidder3.placeBid(auctioneer, 250);

        // Announce Winner
        auction.announceWinner();
    }
}
