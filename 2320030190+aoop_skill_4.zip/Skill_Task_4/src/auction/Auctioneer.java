package auction;

import java.util.ArrayList;
import java.util.List;

// Subject (Observable) that manages bids and notifies Bidders
public class Auctioneer {
    private List<Observer> bidders = new ArrayList<>();
    private String itemName;
    private double highestBid = 0.0;
    private Bidder highestBidder = null;

    public Auctioneer(String itemName) {
        this.itemName = itemName;
    }

    public void registerBidder(Observer bidder) {
        bidders.add(bidder);
    }

    public void receiveBid(Bidder bidder, double bidAmount) {
        if (bidAmount > highestBid) {
            highestBid = bidAmount;
            highestBidder = bidder;
            notifyBidders();
        } else {
            System.out.println(bidder.getName() + "'s bid of $" + bidAmount + " is too low.");
        }
    }

    private void notifyBidders() {
        for (Observer bidder : bidders) {
            bidder.update(itemName, highestBid);
        }
    }

    public void startBidding() {
        System.out.println("Bidding has started for " + itemName);
    }

    public double getHighestBid() {
        return highestBid;
    }

    public Bidder getHighestBidder() {
        return highestBidder;
    }
}
