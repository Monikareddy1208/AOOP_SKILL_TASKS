package auction;

// Observer interface for Bidders
public interface Observer {
    void update(String itemName, double newBid);
}
