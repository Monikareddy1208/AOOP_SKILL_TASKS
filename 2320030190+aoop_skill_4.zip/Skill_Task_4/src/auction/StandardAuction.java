package auction;

// Concrete class using Template Method Pattern
public class StandardAuction extends Auction {
    private Auctioneer auctioneer;

    public StandardAuction(String itemName, double startingPrice, Auctioneer auctioneer) {
        super(itemName, startingPrice);
        this.auctioneer = auctioneer;
    }

    @Override
    protected void displayItem() {
        System.out.println("Auctioning: " + itemName + " | Starting Price: $" + startingPrice);
    }

    @Override
    protected void acceptBids() {
        auctioneer.startBidding();
    }

    @Override
    protected void announceWinner() {
        Bidder highestBidder = auctioneer.getHighestBidder();
        if (highestBidder != null) {
            System.out.println("Winner: " + highestBidder.getName() + " with bid: $" + auctioneer.getHighestBid());
        } else {
            System.out.println("No bids placed.");
        }
    }
}
