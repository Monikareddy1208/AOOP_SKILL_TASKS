package auction;

// Template Method Pattern - Defines auction steps
public abstract class Auction {
    protected String itemName;
    protected double startingPrice;

    public Auction(String itemName, double startingPrice) {
        this.itemName = itemName;
        this.startingPrice = startingPrice;
    }

    // Template method defining the auction process
    public final void startAuction() {
        displayItem();
        acceptBids();
        announceWinner();
    }

    protected abstract void displayItem();
    protected abstract void acceptBids();
    protected abstract void announceWinner();
}
