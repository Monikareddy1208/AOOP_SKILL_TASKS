package auction;

// Concrete Observer (Bidder)
public class Bidder implements Observer {
    private String name;
    private double currentBid = 0.0;

    public Bidder(String name) {
        this.name = name;
    }

    @Override
    public void update(String itemName, double newBid) {
        System.out.println(name + " received update: New highest bid for " + itemName + " is $" + newBid);
    }

    public void placeBid(Auctioneer auctioneer, double bidAmount) {
        auctioneer.receiveBid(this, bidAmount);
    }

    public String getName() {
        return name;
    }

	public double getCurrentBid() {
		return currentBid;
	}

	public void setCurrentBid(double currentBid) {
		this.currentBid = currentBid;
	}
}
